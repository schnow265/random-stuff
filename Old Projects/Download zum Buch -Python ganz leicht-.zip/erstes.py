print("Hallo, wer da?")
Name = input()
print("Du bist also " + Name)
print("Und wie geht es?")
Antwort = input()
print("Dir geht es also " + Antwort);
