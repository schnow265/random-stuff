#Password
Kennwort = "qwertz"
print("Gib dein Kennwort (Password) ein:")
Eingabe = input()
if Eingabe == Kennwort :
  print("Alles OK")
else :
  print("Zugriff verweigert")

