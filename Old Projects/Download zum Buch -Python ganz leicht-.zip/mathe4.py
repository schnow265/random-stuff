# Gerade Zahlen
for Nr in range (0,100,2) :
  print(Nr, end=" ")
print()
print()
# Ungerade Zahlen
for Nr in range (1,100,2) :
  print(Nr, end=" ")
