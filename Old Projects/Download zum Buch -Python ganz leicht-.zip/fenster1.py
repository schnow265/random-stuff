# Fenster
import tkinter
Fenster = tkinter.Tk()
Anzeige = tkinter.Label(Fenster, text="Hallo!")
Anzeige.pack()
# Fenster.mainloop()
