# Frankensteins Labor
from monsterlab import *

# Hauptprogramm
Frank = Monster("Frankie", "ungewöhnlich")
Frank.show()
Albert = GMonster("Bertie", "nachdenklich")
Albert.show()
Sigmund = SMonster("Sigi", "einfühlsam")
Sigmund.show()

