# Boole
Kugel = True
print(Kugel)
Kugel = not Kugel
print(Kugel)
