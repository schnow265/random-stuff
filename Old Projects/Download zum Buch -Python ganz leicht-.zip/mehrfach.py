# Mehrfach-Zuweisung
Zahl1 = 5
Text1 = "Hallo"
print (str(Zahl1),Text1)
Zahl2, Text2 = 5, "Hallo"
print (str(Zahl2),Text2)



