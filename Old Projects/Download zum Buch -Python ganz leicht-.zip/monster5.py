# Frankensteins Labor
import monsterlab

# Hauptprogramm
Frank = monsterlab.Monster("Frankie", "ungewöhnlich")
Frank.show()
Albert = monsterlab.GMonster("Bertie", "nachdenklich")
Albert.show()
Sigmund = monsterlab.SMonster("Sigi", "einfühlsam")
Sigmund.show()

