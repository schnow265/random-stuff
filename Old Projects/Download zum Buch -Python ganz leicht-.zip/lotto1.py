# Lotto
import random
for Nr in range(6) :
  Zufall = random.randint(1,49)
  print("Nr. " + str(Nr+1) + " => " + str(Zufall))
