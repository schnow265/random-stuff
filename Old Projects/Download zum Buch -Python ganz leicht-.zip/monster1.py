﻿# Frankensteins Labor
class Monster :
  # Attribute
  Name = "Frankie"
  Wesen = "ungewöhnlich"
  # Methoden
  def show(self) :
    print("Name : " + self.Name)
    print("Wesen: " + self.Wesen)

# Hauptprogramm
Frank = Monster()
Frank.show()
