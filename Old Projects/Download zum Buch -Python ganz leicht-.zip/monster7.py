# Frankensteins Labor
from monsterlabX import *

# Hauptprogramm
Frank = Monster("Frankie", "ungewöhnlich")
print(Frank.Name);
print(Frank.Wesen)
print(Frank.Type())

