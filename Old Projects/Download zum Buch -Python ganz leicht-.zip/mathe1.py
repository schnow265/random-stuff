# Mathe
print("Gib mal eine Zahl ein: ")
Zahl1 = int(input())
print ("Und gleich noch eine : ")
Zahl2 = int(input())
print ("Und jetzt den Operator (+,-,*,/): ")
Operator = input()
print ("Ergebnis = ")
if Operator == "+" :
  print(Zahl1 + Zahl2)
if Operator == "-" :
  print(Zahl1 - Zahl2)
if Operator == "*" :
  print(Zahl1 * Zahl2)
if Operator == "/" :
  print(Zahl1 / Zahl2)
