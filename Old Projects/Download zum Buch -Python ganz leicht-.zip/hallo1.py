print("Hallo, wer da?")
Name = input()
print("Du bist also " + Name)
print("Und wie geht es?")
Antwort = input()
if Antwort == "gut" :
  print("Das freut mich!")
if Antwort == "schlecht" :
  print("Das tut mir leid!")
