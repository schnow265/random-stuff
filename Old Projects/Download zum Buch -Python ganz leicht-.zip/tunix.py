def tunix() :
  nix = 0
tunix()  
# Funktion definieren
def sayHello() :
  print("Hallo!")
# Funktion aufrufen
sayHello()

