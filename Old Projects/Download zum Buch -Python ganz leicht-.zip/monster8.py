# Frankensteins Labor
from monsterlabX import *

# Hauptprogramm
Frank = Monster("Frankie", "ungewöhnlich")
print(Frank.__Name);
print(Frank.__Wesen)
print(Frank.__Type())

