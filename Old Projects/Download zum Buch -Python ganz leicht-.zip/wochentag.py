# Wochentage
Woche  = ["Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag", "Sonntag"]
for Tag in Woche  :
  print(Tag)
        
