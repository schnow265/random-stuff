# Fenster
import tkinter
Fenster = tkinter.Tk()
Fenster.config(width = 600, height = 400)
# Fenster.mainloop()
