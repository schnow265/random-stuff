# Kehrwert
try :
  print("Gib eine Zahl ein: ")
  Zahl = float(input())
  if Zahl != 0 :
    print(1/Zahl);
  else :
    print("Kein Kehrwert");
except :
  print("Keine Zahl!")

