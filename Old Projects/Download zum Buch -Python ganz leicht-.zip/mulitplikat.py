# Multiplikat
print("Schreib ein Wort: ")
Text1 = input()
Text2 = ""
for Nr in range (0,3) :
  Text2 += Text1
print(Text2)
Text2 = ""
Text2 = 3 * Text1
print(Text2)


